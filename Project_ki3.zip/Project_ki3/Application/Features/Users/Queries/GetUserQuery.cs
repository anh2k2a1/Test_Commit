﻿using Domain.Interfaces.Repositories;
using Domain.Models;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Users.Queries
{
    public record GetUserQuery(string UserId) : IRequest<User>;
}