﻿using Domain.Interfaces.Repositories;
using MediatR;
using Microsoft.AspNetCore.Identity;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Features.Users.Commands
{
    public record LoginUserCommand(string Email, string Password) : IRequest<string>;
}