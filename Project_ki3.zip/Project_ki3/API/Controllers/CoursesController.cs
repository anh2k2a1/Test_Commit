﻿namespace API.Controllers
{
    public class CoursesController
    {
    }
}
