﻿using Microsoft.Extensions.Logging;

namespace Infrastructure.Persistence.Service;

public class LoggingService
{
    private readonly ILogger _logger;

    public LoggingService(ILogger<LoggingService> logger)
    {
        _logger = logger;
    }

    public void LogUserActivity(string userId, string activity, string details = null)
    {
        _logger.LogInformation("User Activity: {UserId} performed {Activity}. Details: {Details}", 
            userId, activity, details ?? "None");
    }

    public void LogSystemEvent(string eventName, string component, string details = null)
    {
        _logger.LogInformation("System Event: {EventName} in {Component}. Details: {Details}", 
            eventName, component, details ?? "None");
    }

    public void LogError(Exception ex, string context, string additionalInfo = null)
    {
        _logger.LogError(ex, "Error in {Context}. Additional Info: {AdditionalInfo}", 
            context, additionalInfo ?? "None");
    }
}