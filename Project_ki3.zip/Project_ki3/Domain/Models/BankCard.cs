﻿using Domain.Enum;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace Domain.Models
{
    public class BankCard
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string UserId { get; set; }

        public string CardNumber { get; set; } // Chỉ lưu 4 số cuối hoặc mã hóa

        public string CardHolderName { get; set; }

        public DateTime ExpirationDate { get; set; }

        public string BankName { get; set; }

        public string AccountNumber { get; set; }

        public string Type { get; set; } // "credit", "debit", "prepaid"

        [BsonRepresentation(BsonType.String)]
        public Currency Currency { get; set; }

        public bool IsDefault { get; set; }
    }
}