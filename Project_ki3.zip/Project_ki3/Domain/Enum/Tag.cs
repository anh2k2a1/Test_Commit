﻿namespace Domain.Enum
{
    public enum Tag
    {
        Investing,
        Budgeting,
        PersonalFinance,
        DebtManagement,
        Saving,
        RetirementPlanning,
        StockMarket,
        Cryptocurrency,
        FinancialLiteracy,
        TaxPlanning,
        RealEstate,
        WealthBuilding,
        Insurance,
        Beginner,
        Advanced
    }
}

