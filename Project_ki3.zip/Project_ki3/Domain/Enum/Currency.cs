﻿namespace Domain.Enum
{
    public enum Currency
    {
        USD,
        VND
    }
}