﻿
namespace Domain.Enum
{
    public enum TransactionType
    {
        Expense,
        Income,
        DebtLoan
    }
}
