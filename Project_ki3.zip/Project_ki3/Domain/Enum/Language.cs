﻿namespace Domain.Enum
{
    public enum Language
    {
        English,
        Vietnamese
    }
}