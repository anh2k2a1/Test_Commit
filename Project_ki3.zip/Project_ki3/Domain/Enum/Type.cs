﻿namespace Domain.Enum
{
    public enum Type
    {
        DebtLoan,
        Expense,
        Income
    }
}
