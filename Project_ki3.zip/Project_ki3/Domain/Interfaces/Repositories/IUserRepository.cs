﻿using Domain.Models;
using System.Threading.Tasks;

namespace Domain.Interfaces.Repositories
{
    public interface IUserRepository
    {
        Task AddAsync(User user);
        Task<User> GetByIdAsync(string id);
        Task<User> GetByEmailAsync(string email);
    }
}